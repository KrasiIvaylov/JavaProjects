package com.example.football.service;

//ToDo - Implement all methods
public interface StatService {
    boolean areImported();

    String readStatsFileContent() ;

    String importStats() ;

}
