package WildFarm.animals;

public abstract class Mammal extends Animal {

    protected Mammal(String animalName, String animalType, double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }

}
