package CarConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Car {
    private String brand;
    private String model;
    private int horsePower;
    List<Parts> parts;

    public Car(String brand, String model, int horsePower) {
        this(brand, model);
        this.horsePower = horsePower;

    }

    public Car(String brand, String model) {
        this(brand);
        this.model = model;

    }

    public Car(String brand) {
        this.brand = brand;
        this.parts = new ArrayList<>();
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getHorsePower() {
        return horsePower;
    }

    public void setHorsePower(int horsePower) {
        this.horsePower = verifyHorsepowerNotLessThenOne(horsePower);
    }

    private int verifyHorsepowerNotLessThenOne(int horsePower) {
        return Math.max(horsePower, 0);
    }

    public void increaseHP(int value) {
        horsePower += verifyHorsepowerNotLessThenOne(horsePower);
    }

    public String carInfo() {
        return this.toString();
    }

    @Override
    public String toString() {
        return String.format("The car is: %s %s - %d HP.",
                this.getBrand(),
                this.getModel() != null ? this.model : "unknown",
                this.getHorsePower() != 0 ? this.horsePower : -1);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Car car = (Car) o;
        return horsePower == car.horsePower &&
                Objects.equals(brand, car.brand) &&
                Objects.equals(model, car.model);
    }

    @Override
    public int hashCode() {
        return Objects.hash(brand, model, horsePower);
    }
}
