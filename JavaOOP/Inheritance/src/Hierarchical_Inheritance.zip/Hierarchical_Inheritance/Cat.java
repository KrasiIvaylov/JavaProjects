package Hierarchical_Inheritance;

public class Cat extends Animal {
    public void meow(){
        System.out.println("meowing....");
    }
}
