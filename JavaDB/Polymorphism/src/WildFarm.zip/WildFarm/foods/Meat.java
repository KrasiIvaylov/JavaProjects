package WildFarm.foods;

public class Meat extends Food {
    public Meat(int quantity) {
        super(quantity);
    }
}
