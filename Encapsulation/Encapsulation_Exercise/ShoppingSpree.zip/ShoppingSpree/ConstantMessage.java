package ShoppingSpree;
public class ConstantMessage {
    private ConstantMessage(){

    }
    public static final String INVALID_NAME_EXCEPTION = "Name cannot be empty";
    public static final String NEGATIVE_MONEY_EXCEPTION = "Money cannot be negative";
}
