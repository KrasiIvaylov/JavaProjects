package com.example.football.models.dto;


public class StatSeedRootDto {
}
