package Hierarchical_Inheritance;

public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
