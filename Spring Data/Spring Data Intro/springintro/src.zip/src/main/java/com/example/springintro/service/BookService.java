package com.example.springintro.service;

import java.io.IOException;

public interface BookService {
    void seedBooks() throws IOException;
}
