package SalaryIncrease;

public class Student extends Person{

    public Student(String firstName, String lastName, int age, double salary) {
        super(firstName, lastName, age, salary);
    }
}
