package robotService.models.robots;

public class Housekeeper extends BaseRobot {

    public Housekeeper(String name, int energy, int happiness, int procedureTime) {
        super(name, energy, happiness, procedureTime);
    }
}
